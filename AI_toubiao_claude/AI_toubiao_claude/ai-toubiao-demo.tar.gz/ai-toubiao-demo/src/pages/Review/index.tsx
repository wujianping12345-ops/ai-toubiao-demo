import { useState } from 'react';
import {
  BarChart3,
  Target,
  Award,
  XCircle,
  PieChart,
  Calendar,
  DollarSign,
  Lightbulb,
  TrendingUp,
  Users,
  FileText,
  AlertCircle,
  CheckCircle,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { reviewList } from '../../data/mockData';

const monthlyStats = [
  { month: '2025-07', total: 12, win: 4, rate: 33 },
  { month: '2025-08', total: 15, win: 6, rate: 40 },
  { month: '2025-09', total: 18, win: 7, rate: 39 },
  { month: '2025-10', total: 14, win: 5, rate: 36 },
  { month: '2025-11', total: 16, win: 6, rate: 38 },
  { month: '2025-12', total: 20, win: 8, rate: 40 },
];

const categoryStats = [
  { name: '信息化建设', count: 35, winCount: 15, rate: 43 },
  { name: '装修装饰', count: 28, winCount: 10, rate: 36 },
  { name: '设备采购', count: 22, winCount: 8, rate: 36 },
  { name: '园林绿化', count: 18, winCount: 6, rate: 33 },
  { name: '其他', count: 12, winCount: 3, rate: 25 },
];

// 失标原因分析
const loseReasons = [
  { reason: '报价偏高', count: 18, percent: 42 },
  { reason: '技术方案不足', count: 12, percent: 28 },
  { reason: '资质不满足', count: 7, percent: 16 },
  { reason: '业绩案例缺乏', count: 4, percent: 9 },
  { reason: '其他原因', count: 2, percent: 5 },
];

// 中标成功因素
const winFactors = [
  { factor: '技术方案创新', contribution: 35 },
  { factor: '报价策略合理', contribution: 28 },
  { factor: '业绩案例丰富', contribution: 20 },
  { factor: '服务承诺到位', contribution: 12 },
  { factor: '团队资质优秀', contribution: 5 },
];

// 竞争对手情报
const competitorIntel = [
  { name: 'A公司', bidCount: 45, winRate: 38, avgPriceRatio: 0.92, strength: '价格优势' },
  { name: 'B公司', bidCount: 38, winRate: 35, avgPriceRatio: 0.95, strength: '本地化' },
  { name: 'C公司', bidCount: 32, winRate: 31, avgPriceRatio: 0.88, strength: '技术实力' },
  { name: '我方', bidCount: 95, winRate: 38, avgPriceRatio: 0.93, strength: '综合能力' },
];

// 详细复盘数据
const detailedReviewList = [
  ...reviewList,
  {
    id: 'REV-003',
    projectName: '某市数字政府平台建设项目',
    bidDate: '2025-10-28',
    result: 'win' as const,
    ourPrice: '2,380万元',
    winningPrice: '2,380万元',
    analysis: '技术方案获得专家一致好评，创新点突出，团队配置合理，报价策略精准。',
    lessons: ['创新方案是制胜关键', '提前了解评委偏好很重要', '合理的人员配置加分明显'],
  },
  {
    id: 'REV-004',
    projectName: '某区智慧社区管理系统',
    bidDate: '2025-09-15',
    result: 'lose' as const,
    ourPrice: '680万元',
    winningPrice: '550万元',
    analysis: '报价高于中标价23.6%，虽然技术方案评分较高但价格差距过大。',
    lessons: ['需要更精准的成本控制', '低价中标项目需调整策略', '考虑硬件云化降低成本'],
  },
  {
    id: 'REV-005',
    projectName: '某医院信息化升级项目',
    bidDate: '2025-08-20',
    result: 'win' as const,
    ourPrice: '1,150万元',
    winningPrice: '1,150万元',
    analysis: '医疗行业经验丰富，案例支撑有力，客户对方案认可度高。',
    lessons: ['垂直行业深耕价值显现', '老客户项目延续性好', '专业团队配置很重要'],
  },
];

export default function Review() {
  const [activeTab, setActiveTab] = useState<'overview' | 'detail' | 'insights'>('overview');
  const [selectedReview, setSelectedReview] = useState(detailedReviewList[0]);

  const totalBids = monthlyStats.reduce((sum, m) => sum + m.total, 0);
  const totalWins = monthlyStats.reduce((sum, m) => sum + m.win, 0);
  const avgWinRate = Math.round((totalWins / totalBids) * 100);

  return (
    <div className="p-6 h-full flex flex-col">
      {/* 页面标题 */}
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-800">投标复盘系统</h1>
        <p className="text-gray-500 mt-1">
          AI分析历史投标数据，总结经验提升中标率
        </p>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Target className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">累计投标</p>
              <p className="text-xl font-semibold text-gray-800">{totalBids} 次</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-100 rounded-lg">
              <Award className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">中标次数</p>
              <p className="text-xl font-semibold text-gray-800">{totalWins} 次</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-100 rounded-lg">
              <PieChart className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">平均中标率</p>
              <p className="text-xl font-semibold text-gray-800">{avgWinRate}%</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-orange-100 rounded-lg">
              <DollarSign className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">中标总额</p>
              <p className="text-xl font-semibold text-gray-800">2.8亿</p>
            </div>
          </div>
        </div>
      </div>

      {/* 标签页 */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm flex-1 flex flex-col overflow-hidden">
        <div className="border-b border-gray-100">
          <div className="flex">
            {[
              { key: 'overview', label: '数据概览', icon: BarChart3 },
              { key: 'detail', label: '复盘详情', icon: Calendar },
              { key: 'insights', label: 'AI洞察', icon: Lightbulb },
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key as typeof activeTab)}
                className={`flex items-center gap-2 px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab.key
                    ? 'border-primary-600 text-primary-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-auto p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* 月度趋势 */}
                <div className="border border-gray-100 rounded-lg p-4">
                  <h3 className="font-medium text-gray-800 mb-4 flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-blue-600" />
                    月度投标趋势
                  </h3>
                  <div className="space-y-3">
                    {monthlyStats.map((stat, index) => (
                      <div key={index} className="flex items-center gap-4">
                        <span className="w-20 text-sm text-gray-500">{stat.month}</span>
                        <div className="flex-1 h-6 bg-gray-100 rounded-full overflow-hidden flex">
                          <div
                            className="h-full bg-green-500"
                            style={{ width: `${(stat.win / stat.total) * 100}%` }}
                          />
                          <div
                            className="h-full bg-gray-300"
                            style={{ width: `${((stat.total - stat.win) / stat.total) * 100}%` }}
                          />
                        </div>
                        <span className="w-16 text-sm text-right">
                          <span className="text-green-600">{stat.win}</span>
                          <span className="text-gray-400">/{stat.total}</span>
                        </span>
                        <span className="w-12 text-sm text-gray-600 text-right">
                          {stat.rate}%
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 分类统计 */}
                <div className="border border-gray-100 rounded-lg p-4">
                  <h3 className="font-medium text-gray-800 mb-4 flex items-center gap-2">
                    <PieChart className="w-5 h-5 text-purple-600" />
                    项目类型分析
                  </h3>
                  <div className="space-y-4">
                    {categoryStats.map((stat, index) => (
                      <div key={index}>
                        <div className="flex items-center justify-between text-sm mb-1">
                          <span className="text-gray-700">{stat.name}</span>
                          <span className="text-gray-500">
                            中标率 <span className="text-primary-600 font-medium">{stat.rate}%</span>
                          </span>
                        </div>
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary-500 rounded-full"
                            style={{ width: `${stat.rate}%` }}
                          />
                        </div>
                        <div className="text-xs text-gray-400 mt-1">
                          投标 {stat.count} 次，中标 {stat.winCount} 次
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* 失标原因与中标因素分析 */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* 失标原因 */}
                <div className="border border-gray-100 rounded-lg p-4">
                  <h3 className="font-medium text-gray-800 mb-4 flex items-center gap-2">
                    <XCircle className="w-5 h-5 text-red-500" />
                    失标原因分析
                  </h3>
                  <div className="space-y-3">
                    {loseReasons.map((item, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <span className="w-28 text-sm text-gray-600">{item.reason}</span>
                        <div className="flex-1 h-3 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-red-400 rounded-full"
                            style={{ width: `${item.percent}%` }}
                          />
                        </div>
                        <span className="text-sm text-gray-500 w-16 text-right">{item.count}次 ({item.percent}%)</span>
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-gray-400 mt-4 pt-3 border-t border-gray-100">
                    * 基于近6个月43次失标项目分析
                  </p>
                </div>

                {/* 中标成功因素 */}
                <div className="border border-gray-100 rounded-lg p-4">
                  <h3 className="font-medium text-gray-800 mb-4 flex items-center gap-2">
                    <Award className="w-5 h-5 text-green-600" />
                    中标成功因素
                  </h3>
                  <div className="space-y-3">
                    {winFactors.map((item, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <span className="w-28 text-sm text-gray-600">{item.factor}</span>
                        <div className="flex-1 h-3 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-green-400 rounded-full"
                            style={{ width: `${item.contribution}%` }}
                          />
                        </div>
                        <span className="text-sm text-gray-500 w-12 text-right">{item.contribution}%</span>
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-gray-400 mt-4 pt-3 border-t border-gray-100">
                    * 基于近6个月36次中标项目分析
                  </p>
                </div>
              </div>

              {/* 竞争对手分析 */}
              <div className="border border-gray-100 rounded-lg p-4">
                <h3 className="font-medium text-gray-800 mb-4 flex items-center gap-2">
                  <Users className="w-5 h-5 text-orange-600" />
                  主要竞争对手对比
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-100">
                        <th className="text-left text-sm font-medium text-gray-500 py-3 px-4">企业</th>
                        <th className="text-center text-sm font-medium text-gray-500 py-3 px-4">投标次数</th>
                        <th className="text-center text-sm font-medium text-gray-500 py-3 px-4">中标率</th>
                        <th className="text-center text-sm font-medium text-gray-500 py-3 px-4">平均报价比</th>
                        <th className="text-center text-sm font-medium text-gray-500 py-3 px-4">核心优势</th>
                      </tr>
                    </thead>
                    <tbody>
                      {competitorIntel.map((comp, index) => (
                        <tr key={index} className={`border-b border-gray-50 ${comp.name === '我方' ? 'bg-primary-50' : ''}`}>
                          <td className="py-3 px-4">
                            <span className={`text-sm font-medium ${comp.name === '我方' ? 'text-primary-700' : 'text-gray-700'}`}>
                              {comp.name}
                            </span>
                          </td>
                          <td className="text-center py-3 px-4 text-sm text-gray-600">{comp.bidCount}</td>
                          <td className="text-center py-3 px-4">
                            <span className={`text-sm font-medium ${
                              comp.winRate >= 38 ? 'text-green-600' : comp.winRate >= 35 ? 'text-blue-600' : 'text-gray-600'
                            }`}>
                              {comp.winRate}%
                            </span>
                          </td>
                          <td className="text-center py-3 px-4 text-sm text-gray-600">{(comp.avgPriceRatio * 100).toFixed(0)}%</td>
                          <td className="text-center py-3 px-4">
                            <span className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded">{comp.strength}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'detail' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* 复盘列表 */}
              <div className="space-y-3">
                <h3 className="font-medium text-gray-800 mb-2 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  历史复盘记录
                </h3>
                {detailedReviewList.map((review) => (
                  <div
                    key={review.id}
                    onClick={() => setSelectedReview(review)}
                    className={`p-4 border rounded-lg cursor-pointer transition-all ${
                      selectedReview.id === review.id
                        ? 'border-primary-500 bg-primary-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          {review.result === 'win' ? (
                            <Award className="w-4 h-4 text-green-600" />
                          ) : (
                            <XCircle className="w-4 h-4 text-red-500" />
                          )}
                          <h4 className="font-medium text-gray-800 text-sm">
                            {review.projectName}
                          </h4>
                        </div>
                        <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                          <span>{review.bidDate}</span>
                          <span>我方报价: {review.ourPrice}</span>
                        </div>
                      </div>
                      <span
                        className={`px-2 py-1 rounded text-xs ${
                          review.result === 'win'
                            ? 'bg-green-100 text-green-700'
                            : 'bg-red-100 text-red-700'
                        }`}
                      >
                        {review.result === 'win' ? '中标' : '未中标'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* 复盘详情 */}
              <div className="border border-gray-100 rounded-lg p-4">
                <h3 className="font-medium text-gray-800 mb-4 flex items-center gap-2">
                  {selectedReview.result === 'win' ? (
                    <Award className="w-5 h-5 text-green-600" />
                  ) : (
                    <XCircle className="w-5 h-5 text-red-500" />
                  )}
                  复盘分析
                </h3>

                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-500">项目名称</p>
                    <p className="text-gray-800">{selectedReview.projectName}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">我方报价</p>
                      <p className="text-gray-800 font-medium">{selectedReview.ourPrice}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">中标价格</p>
                      <p className="text-gray-800 font-medium">{selectedReview.winningPrice}</p>
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-gray-500">AI分析结论</p>
                    <p className="text-gray-700 mt-1">{selectedReview.analysis}</p>
                  </div>

                  <div>
                    <p className="text-sm text-gray-500 mb-2">经验教训</p>
                    <ul className="space-y-2">
                      {selectedReview.lessons.map((lesson, index) => (
                        <li
                          key={index}
                          className="flex items-start gap-2 text-sm text-gray-700"
                        >
                          <span className="w-1.5 h-1.5 bg-primary-500 rounded-full mt-1.5 flex-shrink-0"></span>
                          {lesson}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'insights' && (
            <div className="space-y-6">
              {/* AI智能洞察 */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="font-medium text-gray-800 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-purple-600" />
                    AI智能洞察
                  </h3>
                  {[
                    {
                      title: '报价策略优化',
                      content: '根据近6个月数据分析，您的报价普遍偏高5-10%。建议在信息化建设类项目中，将报价控制在预算的90-93%区间，可提升中标率约8%。',
                      type: 'warning',
                      impact: '+8%中标率',
                    },
                    {
                      title: '优势领域识别',
                      content: '信息化建设类项目中标率最高(43%)，建议继续深耕该领域。同时可考虑拓展智慧城市、数字政府等细分赛道。',
                      type: 'success',
                      impact: '战略聚焦',
                    },
                    {
                      title: '技术方案提升',
                      content: '在落标项目中，技术方案得分普遍低于中标方2-3分。建议加强创新点描述和差异化竞争策略。',
                      type: 'info',
                      impact: '+2-3分',
                    },
                    {
                      title: '资质补强建议',
                      content: '部分项目因缺少CMMI3级认证而失去竞标机会，建议尽快完成资质认证，预计可增加15%的投标机会。',
                      type: 'warning',
                      impact: '+15%机会',
                    },
                  ].map((insight, index) => (
                    <div
                      key={index}
                      className={`p-4 rounded-lg border-l-4 ${
                        insight.type === 'success'
                          ? 'bg-green-50 border-green-500'
                          : insight.type === 'warning'
                          ? 'bg-yellow-50 border-yellow-500'
                          : 'bg-blue-50 border-blue-500'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <h4 className="font-medium text-gray-800 flex items-center gap-2">
                          <Lightbulb className={`w-4 h-4 ${
                            insight.type === 'success'
                              ? 'text-green-600'
                              : insight.type === 'warning'
                              ? 'text-yellow-600'
                              : 'text-blue-600'
                          }`} />
                          {insight.title}
                        </h4>
                        <span className={`text-xs px-2 py-1 rounded ${
                          insight.type === 'success'
                            ? 'bg-green-100 text-green-700'
                            : insight.type === 'warning'
                            ? 'bg-yellow-100 text-yellow-700'
                            : 'bg-blue-100 text-blue-700'
                        }`}>
                          {insight.impact}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mt-2">{insight.content}</p>
                    </div>
                  ))}
                </div>

                {/* 行动建议 */}
                <div className="space-y-4">
                  <h3 className="font-medium text-gray-800 flex items-center gap-2">
                    <Target className="w-5 h-5 text-orange-600" />
                    优化行动计划
                  </h3>

                  <div className="border border-gray-100 rounded-lg p-4">
                    <h4 className="font-medium text-gray-800 mb-3">短期行动（1个月内）</h4>
                    <div className="space-y-3">
                      {[
                        { action: '调整报价策略，控制在预算90-93%', status: 'pending', priority: 'high' },
                        { action: '完善技术方案模板，增加创新点', status: 'in_progress', priority: 'high' },
                        { action: '整理近期优秀案例，丰富业绩库', status: 'done', priority: 'medium' },
                      ].map((item, index) => (
                        <div key={index} className="flex items-center gap-3 p-2 bg-gray-50 rounded">
                          {item.status === 'done' ? (
                            <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                          ) : item.status === 'in_progress' ? (
                            <AlertCircle className="w-4 h-4 text-blue-500 flex-shrink-0" />
                          ) : (
                            <div className="w-4 h-4 border-2 border-gray-300 rounded flex-shrink-0" />
                          )}
                          <span className={`text-sm flex-1 ${item.status === 'done' ? 'text-gray-400 line-through' : 'text-gray-700'}`}>
                            {item.action}
                          </span>
                          <span className={`text-xs px-2 py-0.5 rounded ${
                            item.priority === 'high' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                          }`}>
                            {item.priority === 'high' ? '优先' : '建议'}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="border border-gray-100 rounded-lg p-4">
                    <h4 className="font-medium text-gray-800 mb-3">中期行动（3个月内）</h4>
                    <div className="space-y-3">
                      {[
                        { action: '启动CMMI3级认证申请流程', priority: 'high' },
                        { action: '建立竞争对手情报跟踪机制', priority: 'medium' },
                        { action: '组建专业化的智慧城市团队', priority: 'medium' },
                        { action: '与主要供应商建立战略合作', priority: 'low' },
                      ].map((item, index) => (
                        <div key={index} className="flex items-center gap-3 p-2 bg-gray-50 rounded">
                          <ArrowRight className="w-4 h-4 text-gray-400 flex-shrink-0" />
                          <span className="text-sm flex-1 text-gray-700">{item.action}</span>
                          <span className={`text-xs px-2 py-0.5 rounded ${
                            item.priority === 'high' ? 'bg-red-100 text-red-700' :
                            item.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' : 'bg-gray-100 text-gray-600'
                          }`}>
                            {item.priority === 'high' ? '优先' : item.priority === 'medium' ? '建议' : '可选'}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 预期效果 */}
                  <div className="p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border border-green-100">
                    <h4 className="font-medium text-gray-800 mb-3 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-green-600" />
                      预期优化效果
                    </h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-green-600">45%</p>
                        <p className="text-xs text-gray-500">预期中标率</p>
                        <p className="text-xs text-green-600">↑ 7%</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-blue-600">3.5亿</p>
                        <p className="text-xs text-gray-500">预期年中标额</p>
                        <p className="text-xs text-blue-600">↑ 25%</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* 知识库更新建议 */}
              <div className="border border-gray-100 rounded-lg p-4">
                <h3 className="font-medium text-gray-800 mb-4 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  投标知识库更新建议
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    {
                      title: '技术方案库',
                      items: ['新增智慧城市方案模板', '更新数字政府最佳实践', '补充信创适配方案'],
                      count: 156,
                      newCount: 12,
                    },
                    {
                      title: '报价参考库',
                      items: ['更新人力成本基准', '调整硬件价格参数', '新增云服务报价模型'],
                      count: 89,
                      newCount: 8,
                    },
                    {
                      title: '业绩案例库',
                      items: ['整理近期中标案例', '补充客户评价材料', '更新项目实施照片'],
                      count: 234,
                      newCount: 15,
                    },
                  ].map((lib, index) => (
                    <div key={index} className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium text-gray-800">{lib.title}</h4>
                        <span className="text-xs text-gray-500">
                          共 {lib.count} 条 <span className="text-green-600">(+{lib.newCount})</span>
                        </span>
                      </div>
                      <ul className="space-y-2">
                        {lib.items.map((item, i) => (
                          <li key={i} className="flex items-center gap-2 text-sm text-gray-600">
                            <CheckCircle className="w-3 h-3 text-primary-500" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
