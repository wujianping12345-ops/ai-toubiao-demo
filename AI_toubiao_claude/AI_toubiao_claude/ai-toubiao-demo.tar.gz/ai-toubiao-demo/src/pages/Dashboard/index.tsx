import { useNavigate } from 'react-router-dom';
import {
  FileSearch,
  TrendingUp,
  Target,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Search,
  FileText,
  BookOpen,
  BarChart3,
  AlertTriangle,
  Calendar,
  Sparkles,
  ChevronRight,
  Bell,
} from 'lucide-react';
import { statistics, bidInfoList } from '../../data/mockData';

// 待办任务数据
const todoItems = [
  { id: 1, title: '完成智慧城市项目投标文件', deadline: '2026-01-25', priority: 'high', type: 'doc' },
  { id: 2, title: '跟进浦东新区装修项目', deadline: '2026-01-26', priority: 'medium', type: 'follow' },
  { id: 3, title: '提交医疗设备采购资质材料', deadline: '2026-01-28', priority: 'high', type: 'material' },
];

// 即将到期项目
const expiringBids = bidInfoList.filter(bid => bid.status === 'new' || bid.status === 'tracking').slice(0, 3);

// AI推荐项目
const aiRecommendations = [
  { title: '深圳市数字政府建设项目', match: 96, reason: '与企业资质高度匹配' },
  { title: '广州智慧交通平台升级', match: 93, reason: '技术栈完全匹配' },
  { title: '杭州城市大脑三期工程', match: 91, reason: '有成功案例支撑' },
];

const statCards = [
  {
    title: '今日新增招标',
    value: statistics.newBidsToday,
    unit: '条',
    icon: FileSearch,
    trend: '+12%',
    trendUp: true,
    color: 'bg-blue-500',
  },
  {
    title: '跟踪中项目',
    value: statistics.trackingBids,
    unit: '个',
    icon: Target,
    trend: '+3',
    trendUp: true,
    color: 'bg-green-500',
  },
  {
    title: '投标中标率',
    value: statistics.winRate,
    unit: '%',
    icon: TrendingUp,
    trend: '+2.3%',
    trendUp: true,
    color: 'bg-purple-500',
  },
  {
    title: '累计中标金额',
    value: statistics.totalAmount,
    unit: '',
    icon: Clock,
    trend: '本年度',
    trendUp: true,
    color: 'bg-orange-500',
  },
];

export default function Dashboard() {
  const navigate = useNavigate();
  const recentBids = bidInfoList.slice(0, 5);

  return (
    <div className="p-6">
      {/* 页面标题 */}
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-800">工作台</h1>
        <p className="text-gray-500 mt-1">欢迎使用AI投标黑马智能投标系统</p>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {statCards.map((card, index) => (
          <div
            key={index}
            className="bg-white rounded-xl p-5 border border-gray-100 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-gray-500 text-sm">{card.title}</p>
                <div className="flex items-baseline gap-1 mt-2">
                  <span className="text-2xl font-semibold text-gray-800">
                    {card.value}
                  </span>
                  <span className="text-gray-500 text-sm">{card.unit}</span>
                </div>
                <div className="flex items-center gap-1 mt-2">
                  {card.trendUp ? (
                    <ArrowUpRight className="w-4 h-4 text-green-500" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4 text-red-500" />
                  )}
                  <span
                    className={`text-sm ${
                      card.trendUp ? 'text-green-500' : 'text-red-500'
                    }`}
                  >
                    {card.trend}
                  </span>
                </div>
              </div>
              <div className={`${card.color} p-3 rounded-lg`}>
                <card.icon className="w-5 h-5 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* 内容区域 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 最新招标信息 */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-gray-100 shadow-sm">
          <div className="p-4 border-b border-gray-100">
            <h2 className="font-semibold text-gray-800">最新招标信息</h2>
          </div>
          <div className="p-4">
            <div className="space-y-3">
              {recentBids.map((bid) => (
                <div
                  key={bid.id}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                >
                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-medium text-gray-800 truncate">
                      {bid.title}
                    </h3>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-xs text-gray-500">{bid.region}</span>
                      <span className="text-xs text-gray-500">
                        预算: {bid.budget}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div
                      className={`px-2 py-1 rounded text-xs ${
                        bid.matchScore >= 90
                          ? 'bg-green-100 text-green-700'
                          : bid.matchScore >= 80
                          ? 'bg-blue-100 text-blue-700'
                          : 'bg-gray-100 text-gray-700'
                      }`}
                    >
                      匹配度 {bid.matchScore}%
                    </div>
                    <span
                      className={`px-2 py-1 rounded text-xs ${
                        bid.status === 'new'
                          ? 'bg-red-100 text-red-700'
                          : bid.status === 'tracking'
                          ? 'bg-yellow-100 text-yellow-700'
                          : bid.status === 'applied'
                          ? 'bg-blue-100 text-blue-700'
                          : 'bg-gray-100 text-gray-700'
                      }`}
                    >
                      {bid.status === 'new'
                        ? '新发布'
                        : bid.status === 'tracking'
                        ? '跟踪中'
                        : bid.status === 'applied'
                        ? '已投标'
                        : '已结束'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 快捷操作 */}
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm">
          <div className="p-4 border-b border-gray-100">
            <h2 className="font-semibold text-gray-800">快捷操作</h2>
          </div>
          <div className="p-4">
            <div className="space-y-3">
              <button
                onClick={() => navigate('/info-collect')}
                className="w-full p-3 bg-primary-50 text-primary-600 rounded-lg hover:bg-primary-100 transition-colors text-left flex items-center justify-between"
              >
                <div>
                  <div className="font-medium flex items-center gap-2">
                    <Search className="w-4 h-4" />
                    智能搜索招标
                  </div>
                  <div className="text-xs text-primary-500 mt-1">
                    AI自动匹配优质项目
                  </div>
                </div>
                <ChevronRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => navigate('/doc-generate')}
                className="w-full p-3 bg-green-50 text-green-600 rounded-lg hover:bg-green-100 transition-colors text-left flex items-center justify-between"
              >
                <div>
                  <div className="font-medium flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    生成投标文件
                  </div>
                  <div className="text-xs text-green-500 mt-1">
                    一键生成标准投标书
                  </div>
                </div>
                <ChevronRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => navigate('/pre-layout')}
                className="w-full p-3 bg-purple-50 text-purple-600 rounded-lg hover:bg-purple-100 transition-colors text-left flex items-center justify-between"
              >
                <div>
                  <div className="font-medium flex items-center gap-2">
                    <BookOpen className="w-4 h-4" />
                    查看政策动态
                  </div>
                  <div className="text-xs text-purple-500 mt-1">
                    最新招投标政策解读
                  </div>
                </div>
                <ChevronRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => navigate('/review')}
                className="w-full p-3 bg-orange-50 text-orange-600 rounded-lg hover:bg-orange-100 transition-colors text-left flex items-center justify-between"
              >
                <div>
                  <div className="font-medium flex items-center gap-2">
                    <BarChart3 className="w-4 h-4" />
                    投标复盘分析
                  </div>
                  <div className="text-xs text-orange-500 mt-1">
                    分析历史投标数据
                  </div>
                </div>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 第二行：待办任务、即将到期、AI推荐 */}
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 待办任务 */}
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm">
          <div className="p-4 border-b border-gray-100 flex items-center justify-between">
            <h2 className="font-semibold text-gray-800 flex items-center gap-2">
              <Bell className="w-4 h-4 text-orange-500" />
              待办任务
            </h2>
            <span className="text-xs text-gray-400">{todoItems.length} 项待处理</span>
          </div>
          <div className="p-4">
            <div className="space-y-3">
              {todoItems.map((item) => (
                <div
                  key={item.id}
                  className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                >
                  <div className={`mt-0.5 w-2 h-2 rounded-full flex-shrink-0 ${
                    item.priority === 'high' ? 'bg-red-500' : 'bg-yellow-500'
                  }`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800 truncate">{item.title}</p>
                    <p className="text-xs text-gray-500 mt-1 flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      截止 {item.deadline}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 即将到期项目 */}
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm">
          <div className="p-4 border-b border-gray-100 flex items-center justify-between">
            <h2 className="font-semibold text-gray-800 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-500" />
              即将到期
            </h2>
            <button
              onClick={() => navigate('/info-collect')}
              className="text-xs text-primary-600 hover:underline"
            >
              查看全部
            </button>
          </div>
          <div className="p-4">
            <div className="space-y-3">
              {expiringBids.map((bid) => (
                <div
                  key={bid.id}
                  className="p-3 border border-orange-100 bg-orange-50 rounded-lg"
                >
                  <p className="text-sm font-medium text-gray-800 truncate">{bid.title}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xs text-gray-500">{bid.region}</span>
                    <span className="text-xs text-orange-600 font-medium flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {bid.deadline}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* AI智能推荐 */}
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm">
          <div className="p-4 border-b border-gray-100 flex items-center justify-between">
            <h2 className="font-semibold text-gray-800 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-500" />
              AI智能推荐
            </h2>
            <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded">今日更新</span>
          </div>
          <div className="p-4">
            <div className="space-y-3">
              {aiRecommendations.map((item, index) => (
                <div
                  key={index}
                  className="p-3 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg hover:shadow-sm transition-shadow cursor-pointer"
                >
                  <div className="flex items-start justify-between">
                    <p className="text-sm font-medium text-gray-800 flex-1 truncate">{item.title}</p>
                    <span className="text-sm font-semibold text-green-600 ml-2">{item.match}%</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-purple-500" />
                    {item.reason}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 系统能力介绍 */}
      <div className="mt-6 bg-gradient-to-r from-primary-600 to-primary-700 rounded-xl p-6 text-white">
        <h2 className="text-lg font-semibold mb-4">AI投标黑马 - 五大核心能力</h2>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {[
            { title: '信息收集', desc: '全网招标信息智能抓取' },
            { title: '前置布局', desc: '政策法规智能分析' },
            { title: '方案定制', desc: 'AI智能方案匹配' },
            { title: '文件生成', desc: '一键生成投标文件' },
            { title: '投标复盘', desc: '中标率智能分析' },
          ].map((item, index) => (
            <div key={index} className="text-center">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-2">
                <span className="font-semibold">{index + 1}</span>
              </div>
              <div className="font-medium">{item.title}</div>
              <div className="text-xs text-white/80 mt-1">{item.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
