import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Search,
  Filter,
  RefreshCw,
  Star,
  StarOff,
  MapPin,
  Calendar,
  Banknote,
  ChevronDown,
  X,
  Building2,
  Clock,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  CheckSquare,
  Square,
  FileText,
} from 'lucide-react';
import { bidInfoList, type BidInfo } from '../../data/mockData';

const regions = ['全部地区', '浙江省', '上海市', '广东省', '北京市', '江苏省'];
const categories = ['全部类型', '信息化建设', '装修装饰', '设备采购', '园林绿化', '医疗设备'];
const statuses = ['全部状态', '新发布', '跟踪中', '已投标', '已结束'];
const budgetRanges = ['全部预算', '100万以下', '100-500万', '500-1000万', '1000万以上'];

export default function InfoCollect() {
  const navigate = useNavigate();
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedRegion, setSelectedRegion] = useState('全部地区');
  const [selectedCategory, setSelectedCategory] = useState('全部类型');
  const [selectedStatus, setSelectedStatus] = useState('全部状态');
  const [selectedBudget, setSelectedBudget] = useState('全部预算');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [selectedBid, setSelectedBid] = useState<BidInfo | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 2000);
  };

  const toggleFavorite = (id: string) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    );
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === filteredBids.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredBids.map((bid) => bid.id));
    }
  };

  const handleBatchFavorite = () => {
    setFavorites((prev) => [...new Set([...prev, ...selectedIds])]);
    setSelectedIds([]);
  };

  const handleBatchClearSelection = () => {
    setSelectedIds([]);
  };

  // 解析预算金额用于筛选
  const parseBudget = (budget: string): number => {
    const num = parseFloat(budget.replace(/[^0-9.]/g, ''));
    if (budget.includes('亿')) return num * 10000;
    return num;
  };

  const getStatusConfig = (status: BidInfo['status']) => {
    switch (status) {
      case 'new':
        return { label: '新发布', color: 'bg-red-100 text-red-700', icon: AlertCircle };
      case 'tracking':
        return { label: '跟踪中', color: 'bg-yellow-100 text-yellow-700', icon: Clock };
      case 'applied':
        return { label: '已投标', color: 'bg-blue-100 text-blue-700', icon: CheckCircle2 };
      case 'ended':
        return { label: '已结束', color: 'bg-gray-100 text-gray-700', icon: CheckCircle2 };
      default:
        return { label: '未知', color: 'bg-gray-100 text-gray-700', icon: AlertCircle };
    }
  };

  const filteredBids = bidInfoList.filter((bid) => {
    const matchKeyword = searchKeyword
      ? bid.title.includes(searchKeyword) || bid.region.includes(searchKeyword)
      : true;
    const matchRegion =
      selectedRegion === '全部地区' || bid.region.includes(selectedRegion.replace('省', '').replace('市', ''));
    const matchCategory =
      selectedCategory === '全部类型' || bid.category === selectedCategory;
    const matchStatus =
      selectedStatus === '全部状态' ||
      (selectedStatus === '新发布' && bid.status === 'new') ||
      (selectedStatus === '跟踪中' && bid.status === 'tracking') ||
      (selectedStatus === '已投标' && bid.status === 'applied') ||
      (selectedStatus === '已结束' && bid.status === 'ended');

    // 预算筛选
    const budgetNum = parseBudget(bid.budget);
    const matchBudget =
      selectedBudget === '全部预算' ||
      (selectedBudget === '100万以下' && budgetNum < 100) ||
      (selectedBudget === '100-500万' && budgetNum >= 100 && budgetNum < 500) ||
      (selectedBudget === '500-1000万' && budgetNum >= 500 && budgetNum < 1000) ||
      (selectedBudget === '1000万以上' && budgetNum >= 1000);

    return matchKeyword && matchRegion && matchCategory && matchStatus && matchBudget;
  });

  return (
    <div className="p-6 h-full flex flex-col">
      {/* 页面标题 */}
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-800">信息收集系统</h1>
        <p className="text-gray-500 mt-1">
          AI智能抓取全网招标信息，自动匹配优质项目
        </p>
      </div>

      {/* 搜索和筛选 */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4 mb-4">
        <div className="flex flex-wrap gap-4">
          {/* 搜索框 */}
          <div className="flex-1 min-w-[300px]">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="搜索项目名称、地区、关键词..."
                value={searchKeyword}
                onChange={(e) => setSearchKeyword(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
            </div>
          </div>

          {/* 筛选下拉 */}
          <div className="flex gap-2">
            <div className="relative">
              <select
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value)}
                className="appearance-none pl-3 pr-8 py-2 border border-gray-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-primary-500 text-sm"
              >
                {regions.map((region) => (
                  <option key={region} value={region}>
                    {region}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
            </div>

            <div className="relative">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="appearance-none pl-3 pr-8 py-2 border border-gray-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-primary-500 text-sm"
              >
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
            </div>

            <div className="relative">
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="appearance-none pl-3 pr-8 py-2 border border-gray-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-primary-500 text-sm"
              >
                {statuses.map((status) => (
                  <option key={status} value={status}>
                    {status}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
            </div>

            <div className="relative">
              <select
                value={selectedBudget}
                onChange={(e) => setSelectedBudget(e.target.value)}
                className="appearance-none pl-3 pr-8 py-2 border border-gray-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-primary-500 text-sm"
              >
                {budgetRanges.map((range) => (
                  <option key={range} value={range}>
                    {range}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
            </div>

            <button
              onClick={handleRefresh}
              className={`flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors ${
                isRefreshing ? 'opacity-75' : ''
              }`}
            >
              <RefreshCw
                className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`}
              />
              {isRefreshing ? '刷新中...' : '刷新数据'}
            </button>
          </div>
        </div>

        {/* 数据来源说明 */}
        <div className="mt-4 flex items-center gap-4 text-xs text-gray-500">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 bg-green-500 rounded-full"></span>
            已接入 12 个数据源
          </span>
          <span>|</span>
          <span>最近更新: 2026-01-23 16:30</span>
          <span>|</span>
          <span>今日新增: 48 条</span>
        </div>
      </div>

      {/* 列表和详情 */}
      <div className="flex-1 flex gap-4 min-h-0">
        {/* 招标列表 */}
        <div className="flex-1 bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden flex flex-col">
          <div className="p-4 border-b border-gray-100 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={toggleSelectAll}
                className="flex items-center gap-2 text-sm text-gray-600 hover:text-primary-600"
              >
                {selectedIds.length === filteredBids.length && filteredBids.length > 0 ? (
                  <CheckSquare className="w-4 h-4 text-primary-600" />
                ) : (
                  <Square className="w-4 h-4" />
                )}
                全选
              </button>
              <span className="text-sm text-gray-500">
                共 {filteredBids.length} 条结果
                {selectedIds.length > 0 && (
                  <span className="ml-2 text-primary-600">
                    (已选 {selectedIds.length} 项)
                  </span>
                )}
              </span>
            </div>
            <div className="flex items-center gap-3">
              {selectedIds.length > 0 && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleBatchFavorite}
                    className="flex items-center gap-1 px-3 py-1.5 text-sm bg-yellow-50 text-yellow-700 rounded-lg hover:bg-yellow-100 transition-colors"
                  >
                    <Star className="w-4 h-4" />
                    批量收藏
                  </button>
                  <button
                    onClick={() => navigate('/doc-generate')}
                    className="flex items-center gap-1 px-3 py-1.5 text-sm bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors"
                  >
                    <FileText className="w-4 h-4" />
                    批量生成
                  </button>
                  <button
                    onClick={handleBatchClearSelection}
                    className="flex items-center gap-1 px-3 py-1.5 text-sm bg-gray-50 text-gray-600 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <X className="w-4 h-4" />
                    取消
                  </button>
                </div>
              )}
              <div className="flex items-center gap-2 text-sm">
                <Filter className="w-4 h-4 text-gray-400" />
                <span className="text-gray-500">按匹配度排序</span>
              </div>
            </div>
          </div>

          <div className="flex-1 overflow-auto">
            {filteredBids.map((bid) => {
              const statusConfig = getStatusConfig(bid.status);
              const isSelected = selectedIds.includes(bid.id);
              return (
                <div
                  key={bid.id}
                  onClick={() => setSelectedBid(bid)}
                  className={`p-4 border-b border-gray-50 hover:bg-gray-50 cursor-pointer transition-colors ${
                    selectedBid?.id === bid.id ? 'bg-primary-50' : ''
                  } ${isSelected ? 'bg-blue-50' : ''}`}
                >
                  <div className="flex items-start gap-3">
                    {/* 选择框 */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleSelect(bid.id);
                      }}
                      className="mt-1 flex-shrink-0"
                    >
                      {isSelected ? (
                        <CheckSquare className="w-5 h-5 text-primary-600" />
                      ) : (
                        <Square className="w-5 h-5 text-gray-300 hover:text-gray-400" />
                      )}
                    </button>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-medium text-gray-800 truncate">
                          {bid.title}
                        </h3>
                        <span
                          className={`px-2 py-0.5 rounded text-xs ${statusConfig.color}`}
                        >
                          {statusConfig.label}
                        </span>
                        {bid.matchScore >= 90 && (
                          <span className="px-2 py-0.5 rounded text-xs bg-purple-100 text-purple-700 flex items-center gap-1">
                            <Sparkles className="w-3 h-3" />
                            AI推荐
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          {bid.region}
                        </span>
                        <span className="flex items-center gap-1">
                          <Banknote className="w-4 h-4" />
                          {bid.budget}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          截止 {bid.deadline}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div
                        className={`px-3 py-1 rounded-full text-sm font-medium ${
                          bid.matchScore >= 90
                            ? 'bg-green-100 text-green-700'
                            : bid.matchScore >= 80
                            ? 'bg-blue-100 text-blue-700'
                            : 'bg-gray-100 text-gray-700'
                        }`}
                      >
                        {bid.matchScore}分
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFavorite(bid.id);
                        }}
                        className="p-1 hover:bg-gray-100 rounded"
                      >
                        {favorites.includes(bid.id) ? (
                          <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                        ) : (
                          <StarOff className="w-5 h-5 text-gray-400" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 详情面板 */}
        {selectedBid && (
          <div className="w-[400px] bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden flex flex-col">
            <div className="p-4 border-b border-gray-100 flex items-center justify-between">
              <h3 className="font-semibold text-gray-800">项目详情</h3>
              <button
                onClick={() => setSelectedBid(null)}
                className="p-1 hover:bg-gray-100 rounded"
              >
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>

            <div className="flex-1 overflow-auto p-4">
              <h4 className="font-medium text-gray-800 mb-4">
                {selectedBid.title}
              </h4>

              <div className="space-y-4">
                <div className="flex items-center gap-3 text-sm">
                  <Building2 className="w-5 h-5 text-gray-400" />
                  <span className="text-gray-500">来源:</span>
                  <span className="text-gray-800">{selectedBid.source}</span>
                </div>

                <div className="flex items-center gap-3 text-sm">
                  <MapPin className="w-5 h-5 text-gray-400" />
                  <span className="text-gray-500">地区:</span>
                  <span className="text-gray-800">{selectedBid.region}</span>
                </div>

                <div className="flex items-center gap-3 text-sm">
                  <Banknote className="w-5 h-5 text-gray-400" />
                  <span className="text-gray-500">预算:</span>
                  <span className="text-gray-800 font-medium">
                    {selectedBid.budget}
                  </span>
                </div>

                <div className="flex items-center gap-3 text-sm">
                  <Calendar className="w-5 h-5 text-gray-400" />
                  <span className="text-gray-500">截止日期:</span>
                  <span className="text-gray-800">{selectedBid.deadline}</span>
                </div>

                <div className="pt-4 border-t border-gray-100">
                  <h5 className="font-medium text-gray-800 mb-2">项目描述</h5>
                  <p className="text-sm text-gray-600 leading-relaxed">
                    {selectedBid.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-gray-100">
                  <h5 className="font-medium text-gray-800 mb-2">资质要求</h5>
                  <ul className="space-y-2">
                    {selectedBid.requirements.map((req, index) => (
                      <li
                        key={index}
                        className="flex items-start gap-2 text-sm text-gray-600"
                      >
                        <span className="w-1.5 h-1.5 bg-primary-500 rounded-full mt-2 flex-shrink-0"></span>
                        {req}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-4 border-t border-gray-100">
                  <h5 className="font-medium text-gray-800 mb-2">联系方式</h5>
                  <div className="text-sm text-gray-600">
                    <p>联系人: {selectedBid.contactPerson}</p>
                    <p>电话: {selectedBid.contactPhone}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-gray-100 flex gap-3">
              <button className="flex-1 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors text-sm">
                加入跟踪
              </button>
              <button className="flex-1 py-2 border border-primary-600 text-primary-600 rounded-lg hover:bg-primary-50 transition-colors text-sm">
                生成投标文件
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
